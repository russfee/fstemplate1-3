<?php // Paragraph Module ?>

<div class="row constrain" style="<?php the_sub_field('row_padding_top'); ?><?php the_sub_field('row_padding_bottom'); ?>">
	<div style="margin: 0 auto; width: <?php the_sub_field('text_width'); ?>; text-align: <?php the_sub_field('text_align'); ?>; color: <?php the_sub_field('text_colour'); ?>; font-size: <?php the_sub_field('text_size'); ?>;">
	<?php the_sub_field('paragraph'); ?>
	</div>
	
</div> <!--row-->
