<?php // Paragraph Module ?>

<div class="row constrain">
	<?php the_sub_field('paragraph'); ?>
</div> <!--row-->
