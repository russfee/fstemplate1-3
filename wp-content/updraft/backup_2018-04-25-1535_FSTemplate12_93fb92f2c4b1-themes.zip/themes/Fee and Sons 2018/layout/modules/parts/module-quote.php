<?php // Quote Module ?>
<div class="row constrain">
<div class="flexible-test-2">
	<?php the_sub_field('quote'); ?>
</div>
<div class="flexible-test-3">
	<?php the_sub_field('author'); ?>
</div>
</div> <!--row-->